# Neural Map Maker (mobile-first prototype)

This repository is a minimal Android WebView app. The interface and learning prototype live in `app/src/main/assets/index.html`; GitHub Actions builds an installable debug APK.

## Build an APK on GitHub from your phone

1. Create a new GitHub repository.
2. Upload the contents of this project ZIP to the repository root (make sure `.github/workflows/build-apk.yml` is included).
3. Open **Actions** and select **Build Neural Map Maker APK**.
4. Tap **Run workflow**, or push/commit to `main` or `master` to trigger a build.
5. Open the completed run, scroll to **Artifacts**, and download `neural-map-maker-debug-apk`.
6. Extract the ZIP artifact and install `app-debug.apk` on your Android device. Android may ask you to allow installs from your browser/file manager.

## What this prototype does

- Starts with no pretrained model or imported model weights.
- Accepts word lists and fact text files.
- Extracts simple subject–relation–object triples from common English patterns.
- Learns a small concept-space representation from the supplied facts and shows a force-style concept map.
- Provides a basic question-answering test panel based on the facts it has seen.
- Stores the current workspace in browser local storage.
- Imports images as labeled examples using their filenames. **It does not yet train a visual neural network or understand image pixels.**
- Exports the workspace as JSON.
- Exports a custom GGUF v3 file containing concept vectors and vocabulary metadata. **This file uses a custom architecture name and is not directly runnable in llama.cpp or other standard GGUF inference engines without a matching custom runtime.**

## Honest scope

This is a working prototype for exploring the idea, not a general-purpose language model. It has no pretrained intelligence. The initial learning engine is a lightweight from-scratch concept-space and fact-retrieval system; it does not yet train a deep neural language model. Similarity and simple fact patterns are not equivalent to human language understanding.

## Project layout

- `app/src/main/assets/index.html` — the HTML app and prototype learning engine.
- `app/src/main/java/com/seraj/neuralmapmaker/MainActivity.java` — Android WebView wrapper, file picker, and export bridge.
- `.github/workflows/build-apk.yml` — cloud APK build workflow.
